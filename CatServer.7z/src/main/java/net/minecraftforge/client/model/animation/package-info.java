@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraftforge.client.model.animation;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;
