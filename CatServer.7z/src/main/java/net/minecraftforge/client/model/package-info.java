@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraftforge.client.model;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;
